﻿using System.Text;

namespace Gauss_Calculator
{
    internal class GaussElimination:IDisposable
    {
        private int m;
        private int n;
        internal double[][] a;
        private int flag;
        public GaussElimination(int m, int n)
        {
            this.m = m;
            this.n = n;
            this.a = new double[m][];
            this.flag = 1;
            for(int i = 0; i < m; i++)
            {
                this.a[i] = new double[n];
            }
        }
        public void Dispose()
        {
            this.a = null;
            GC.Collect();
        }
        internal int GaussMethod()
        { // приведение вещественной матрицы  к ступенчатому виду методом Гаусса с выбором максимального разрешающего элемента в столбце.
            int i, j, k, l;
            double r;
            double c = 0.0;
            int count = 0;
            double eps = 0.000001;
            int lastRow = 0;
            i = 0; j = 0; l = 0;
            while (i < m && j < n)
            {
                //инвариант: минор матрицы в столбцах 0..j-1 уже приведен к ступенчатому виду, и строка
                //с индексом i-1 содержит ненулевой элемент в стобце с номером, меньшим чем j

                //ищем максимальный элемент в j-м столбце, начиная с i-й строки
                r = 0.0;
                for (k = i; k < m; ++k)
                {
                    if (Math.Abs(a[k][j]) > r)
                    {
                        l = k; //запомним номер строки
                        r = Math.Abs(a[k][j]); //и максимальный элемент
                    }
                }

                if (r <= eps)
                {
                    flag = 0;
                    for (k = i; k < m; ++k)
                    {
                        a[k][j] = 0.0;
                    }
                    ++j;
                    continue;
                }

                if (l != i)
                {
                    // меняем местами i-ю и l-ю строки
                    for (k = j; k < n; ++k)
                    {
                        r = a[i][k];
                        a[i][k] = a[l][k];
                        a[l][k] = (-r);// меняем знак строки
                    }
                }

                //утверждение: abs(a[i][j]) > eps
                r = a[i][j];
                if (Math.Abs(r) <= eps)
                {
                    flag = 0;
                }

                //обнуляем j-й столбец, начиная со строки i+1, применяя элементарные преобразования 2-го рода
                for (k = i + 1; k < m; ++k)
                {
                    c = (-a[k][j]) / r;
                    //к k-й строке прибавляем i-ю, умноженную на c
                    a[k][j] = 0.0;
                    for (l = j + 1; l < n; ++l)
                    {
                        a[k][l] += c * a[i][l];
                    }
                }
                ++i; ++j; //переходим к следующему минору
                lastRow = i;
            }

            if (lastRow < n - 1) // если ранг матрицы меньше, чем кол-во неизвестных
                flag = -1;
            for (i = 0; i < n; i++)
            {
                if (a[lastRow - 1][i] == 0)
                {
                    count++;
                }
            }
            if (count == n - 1)
            {
                flag = 0;
            }
            return lastRow;
        }
        internal void GaussSolution(int lastRow) {
            StringBuilder str = new StringBuilder();
            switch (flag)
            {
                case -1:
                    {
                        str.Append("Ступенчатый вид матрицы:\r\n");
                        for (int i = 0; i < m; ++i)
                        {
                            for (int j = 0; j < n; ++j)
                            {
                                str.Append(Convert.ToString(Math.Round(a[i][j], 3)));
                                str.Append("  ");
                            }
                            str.Append("\r\n");
                        }
                        str.Append("Решение:\r\n");
                        int[] basis = new int[n];
                        for (int i = 0; i < n; i++)
                        {
                            basis[i] = -1;
                        }
                        for (int i = 0; i < lastRow; i++)
                        { // отмечаем базисные переменные
                            for (int j = 0; j < n; j++)
                            {
                                if (a[i][j] != 0)
                                {
                                    basis[j] = i;
                                    break;
                                }
                            }
                        }
                        double kf = 0;
                        int ind = n;
                        double b;
                        for (int i = lastRow - 1; i >= 0; i--)
                        {
                            double[] result1 = new double[n];
                            for (int bb = ind - 1; bb >= 0; bb--)
                            {
                                if (basis[bb] != -1)
                                {
                                    ind = bb; // находим базисную переменную в строке и выражаем ее
                                    kf = a[i][ind];
                                    break;
                                }
                            }
                            str.Append("X[" + ind + "] = ");
                            b = a[i][n - 1] / kf;
                            for (int j = n - 2; j > ind; j--)
                            {
                                if (basis[j] == -1)
                                {
                                    result1[j] += -a[i][j] / kf;
                                }
                                else
                                { // выражаем базисную переменную 
                                    b += a[basis[j]][n - 1] / a[basis[j]][j] * (-a[i][j]) / kf;
                                    for (int k = n - 2; k > j; k--)
                                    {
                                        result1[k] += -a[basis[j]][k] / a[basis[j]][j] * (-a[i][j]) / kf;

                                    }
                                }
                            }
                            for (int ii = 0; ii < n; ii++)
                            {
                                if (result1[ii] != 0)
                                {
                                    str.Append(Math.Round(result1[ii], 3) + "X[" + ii + "] + ");
                                }
                            }
                            str.Append(Math.Round(b, 3));
                            str.Append("\r\n");
                        }
                        break;
                    }
                case 0:
                    {
                        str.Append("Нет решений\r\n");
                        str.Append("Ступенчатый вид матрицы:\r\n");
                        for (int i = 0; i < m; ++i)
                        {
                            for (int j = 0; j < n; ++j)
                            {
                                str.Append(Convert.ToString(Math.Round(a[i][j], 3)));
                                str.Append("  ");
                            }
                            str.Append("\r\n");
                        }
                        break;
                    }
                case 1:
                    {
                        str.Append("Ступенчатый вид матрицы:\r\n");
                        for (int i = 0; i < m; ++i)
                        {
                            for (int j = 0; j < n; ++j)
                            {
                                str.Append(Convert.ToString(Math.Round(a[i][j], 3)));
                                str.Append("  ");
                            }
                            str.Append("\r\n");
                        }
                        str.Append("Решение:\r\n");
                        double[][] tmp = new double[lastRow][];
                        for (int i = 0; i < lastRow; ++i)
                        {
                            tmp[i] = new double[n];
                        }
                        double[] result1 = new double[lastRow];
                        for (int i = 0; i < lastRow; i++)
                        {
                            for (int j = 0; j < n; j++)
                            {
                                tmp[i][j] = a[i][j];
                            }
                        }

                        for (int i = lastRow - 1; i >= 0; i--)
                        {
                            if (lastRow - i - 1 == 0)
                                result1[0] = tmp[lastRow - 1][n - 1] / tmp[lastRow - 1][n - 2];
                            else
                            {
                                for (int j = n - 1; j > i; j--)
                                    tmp[i][n - 1] -= tmp[i][j - 1] * result1[n - j - 1];
                                if (i < n - 1)
                                {
                                    result1[lastRow - i - 1] = tmp[i][n - 1] / tmp[i][i];
                                }
                            }
                        }
                        str.Append("{  ");
                        for (int i = 0; i < lastRow; i++)
                        {
                            str.Append(Convert.ToString(Math.Round(result1[i], 3))); //
                            str.Append("   ");
                        }
                        str.Append("}\r\n");
                        break;
                    }
            }
            try
            {
                StreamWriter f = new StreamWriter("C:\\Users\\днс\\source\\repos\\Gauss_Calculator\\Gauss_Calculator\\Solution.txt", false);
                f.Write(str.ToString());
                f.Close();
            }
            catch (FileNotFoundException ioEx)
            {
                MessageBox.Show(ioEx.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
