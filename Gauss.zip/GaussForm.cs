
namespace Gauss_Calculator
{
    public partial class GaussForm : Form
    {
        public GaussForm()
        {
            InitializeComponent();
        }
        private GaussElimination g;
        private void GaussEnding()
        {
            if (g != null)
            {
                g.Dispose();
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int row = Convert.ToInt32(numericUpDown1.Value);
            int column = Convert.ToInt32(numericUpDown2.Value);
            Random rnd = new Random();
            int lr = 0;
            Thread thread = new Thread(() =>
            {
                try
                {
                    g = new GaussElimination(row, column);
                    try
                    {
                        StreamWriter f = new StreamWriter("C:\\Users\\���\\source\\repos\\Gauss_Calculator\\Gauss_Calculator\\Matrix.txt", false);
                        f.Write("�������� �������:\r\n");
                        for (int i = 0; i < row; i++)
                        {
                            for (int j = 0; j < column; j++)
                            {
                                g.a[i][j] = (double)rnd.Next(-100, 100);
                                f.Write(Convert.ToString(g.a[i][j]) + ",0 ");
                            }
                            f.Write("\r\n");
                        }
                        f.Close();
                    }
                    catch (FileNotFoundException ioEx)
                    {
                        MessageBox.Show(ioEx.Message, "������", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    lr = g.GaussMethod();
                    g.GaussSolution(lr);
                    Invoke(new MethodInvoker(() => { textBox1.Text = "������ ������"; }));
                }
                finally
                {
                    GaussEnding();
                }
            });
            thread.Start();
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            string filename = openFileDialog1.FileName;
            await Task.Run(() =>
            {
                string[] arr = System.IO.File.ReadAllLines(filename);
                char pattern = ' ';
                String[] nums = arr[0].Split(pattern); // ����������� �������
                int m = 0, n = 0;
                if(nums.Length != 2)
                {
                    MessageBox.Show("������� ������� ����������� �������", "������", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (!(int.TryParse(nums[0], out m)) || !(int.TryParse(nums[1], out n)))
                {
                    MessageBox.Show("������������ ������ �����", "������", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    if(m != (arr.Length - 1) || n != arr[1].Split(pattern).Length)
                    {
                        MessageBox.Show("������� ������� ����������� �������", "������", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    try
                    {
                        g = new GaussElimination(m, n);
                        for (int i = 0; i < m; i++)
                        {
                            String[] t = arr[i + 1].Split(pattern);
                            for (int j = 0; j < n; j++)
                            {
                                if (!(double.TryParse(t[j], out g.a[i][j])))
                                {
                                    MessageBox.Show("������������ ������ �����", "������", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    return;
                                }
                            }
                        }
                        int lr = g.GaussMethod();
                        g.GaussSolution(lr);
                        textBox1.Invoke(new MethodInvoker(delegate { textBox1.Text = "������ ������"; }));

                    }
                    finally 
                    {
                        GaussEnding();
                    }
                }
            });
        }
    }
}